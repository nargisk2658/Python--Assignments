from django.urls import path
from . import views

urlpatterns = [
    path('students/', views.student_api),
    path('students/<int:id>/', views.student_api),
]